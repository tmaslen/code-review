# Technical Test - part one in JavaScript

Make the tests pass. To start...

```
npm install
npm run test
```