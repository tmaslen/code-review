package com.example.questions;

public class Palindrome {
    public static boolean palindromeChecker(String args){
        return false;
    }
}
