package com.example.questions;

public class RemoveDuplicatesFromSortedArray {

    public static int[] removeDuplicates(int[] nums) {
        int[] uniqueSortedArray = new int[1];
        return uniqueSortedArray;
    }
}
