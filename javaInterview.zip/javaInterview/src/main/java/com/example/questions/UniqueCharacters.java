package com.example.questions;

public class UniqueCharacters {
    public static boolean checkCharacters(String args){
        return true;
    }
}
