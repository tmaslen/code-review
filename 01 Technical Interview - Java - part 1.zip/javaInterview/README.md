# Java Interview

Get the tests to pass

## Setup
```
mvn clean install
```

## Run the tests
```
mvn test
```