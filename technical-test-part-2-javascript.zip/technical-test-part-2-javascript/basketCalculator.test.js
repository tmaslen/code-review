const expect = require( "chai" ).expect;

const basketCalculator = require( "./basketCalculator" );

describe( "basketCalculator.js", function () {

  it( "Calculates BASIC basket price correctly", function() {

    expect( basketCalculator( [
      {
        item: "apple",
        quantity: 1
      },{
        item: "brocolli",
        quantity: 1
      },{
        item: "cabbage",
        quantity: 1
      },{
        item: "date",
        quantity: 1
      }
    ] ) ).to.equal(1.15);

  });

  it( "Calculates COMPLEX basket price correctly", function() {

    expect( basketCalculator( [
      {
        item: "apple",
        quantity: 4
      },{
        item: "brocolli",
        quantity: 3
      },{
        item: "cabbage",
        quantity: 7
      },{
        item: "date",
        quantity: 9
      }
    ] ) ).to.equal(5.30);

  });

});