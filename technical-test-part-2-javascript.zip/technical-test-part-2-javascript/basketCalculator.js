module.exports = function () {
  return 0;
}