package com.ec.test.codereview.controller;

import org.junit.Test;

import static org.junit.Assert.*;

public class MyControllerTest {

    @Test
    public void doTheWork() {

//        http://localhost:8080/prime/1073676287
    }
}