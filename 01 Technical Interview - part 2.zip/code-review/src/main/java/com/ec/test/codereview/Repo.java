package com.ec.test.codereview;

import org.springframework.data.repository.CrudRepository;

public interface Repo extends CrudRepository<Prime, Integer> {

}
